import { View, Text, TouchableOpacity, ActivityIndicator } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { WebView } from "react-native-webview";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { ArrowLeft, RotateCcw } from "lucide-react-native";
import { useState, useRef } from "react";

export default function OrderViewScreen() {
  const { url } = useLocalSearchParams();
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const webviewRef = useRef(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  if (!url) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#FFFFFF",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <Text style={{ color: "#EF4444" }}>No URL provided.</Text>
        <TouchableOpacity
          onPress={() => router.back()}
          style={{ marginTop: 16 }}
        >
          <Text style={{ color: "#2563EB" }}>Go back</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View
      style={{ flex: 1, backgroundColor: "#FFFFFF", paddingTop: insets.top }}
    >
      <StatusBar style="dark" />

      {/* Top bar */}
      <View
        style={{
          flexDirection: "row",
          alignItems: "center",
          justifyContent: "space-between",
          paddingHorizontal: 16,
          paddingVertical: 12,
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
          backgroundColor: "#FFFFFF",
        }}
      >
        <TouchableOpacity
          onPress={() => router.back()}
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: 6,
            padding: 4,
          }}
        >
          <ArrowLeft size={20} color="#111827" />
          <Text style={{ fontSize: 15, color: "#111827", fontWeight: "500" }}>
            Back to Scanner
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          onPress={() => {
            setError(false);
            setLoading(true);
            webviewRef.current?.reload();
          }}
          style={{ padding: 4 }}
        >
          <RotateCcw size={18} color="#6B7280" />
        </TouchableOpacity>
      </View>

      {/* Loading indicator */}
      {loading && !error && (
        <View
          style={{
            position: "absolute",
            top: insets.top + 60,
            left: 0,
            right: 0,
            bottom: 0,
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "#FFFFFF",
            zIndex: 10,
          }}
        >
          <ActivityIndicator size="large" color="#2563EB" />
          <Text style={{ marginTop: 16, color: "#6B7280", fontSize: 14 }}>
            Loading menu...
          </Text>
        </View>
      )}

      {/* Error state */}
      {error && (
        <View
          style={{
            position: "absolute",
            top: insets.top + 60,
            left: 0,
            right: 0,
            bottom: 0,
            justifyContent: "center",
            alignItems: "center",
            backgroundColor: "#FFFFFF",
            zIndex: 10,
            paddingHorizontal: 32,
          }}
        >
          <Text
            style={{
              fontSize: 18,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 8,
              textAlign: "center",
            }}
          >
            Couldn't load menu
          </Text>
          <Text
            style={{
              fontSize: 14,
              color: "#6B7280",
              textAlign: "center",
              marginBottom: 24,
            }}
          >
            Make sure you're connected to the internet and the QR code is still
            valid.
          </Text>
          <TouchableOpacity
            onPress={() => {
              setError(false);
              setLoading(true);
              webviewRef.current?.reload();
            }}
            style={{
              backgroundColor: "#2563EB",
              borderRadius: 10,
              paddingVertical: 12,
              paddingHorizontal: 28,
            }}
          >
            <Text style={{ color: "#FFFFFF", fontWeight: "600" }}>
              Try Again
            </Text>
          </TouchableOpacity>
        </View>
      )}

      {/* WebView */}
      <WebView
        ref={webviewRef}
        source={{ uri: url }}
        style={{ flex: 1 }}
        onLoadStart={() => setLoading(true)}
        onLoadEnd={() => setLoading(false)}
        onError={() => {
          setLoading(false);
          setError(true);
        }}
      />
    </View>
  );
}
