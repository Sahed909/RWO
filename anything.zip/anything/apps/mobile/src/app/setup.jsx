import { View, Text, TextInput, TouchableOpacity } from "react-native";
import { useState } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import { ArrowLeft } from "lucide-react-native";

export default function SetupScreen() {
  const [name, setName] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const handleSetup = async () => {
    if (!name.trim()) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/restaurants", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name }),
      });
      const data = await res.json();
      if (data.id) {
        await AsyncStorage.setItem("restaurant_id", data.id.toString());
        router.replace("/(tabs)");
      }
    } catch (e) {
      alert("Error setting up restaurant");
    } finally {
      setSubmitting(false);
    }
  };

  const goBack = async () => {
    await AsyncStorage.removeItem("app_mode");
    router.replace("/mode-select");
  };

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#FFFFFF",
        paddingTop: insets.top,
        paddingBottom: insets.bottom,
        paddingHorizontal: 24,
      }}
    >
      <StatusBar style="dark" />

      {/* Back */}
      <TouchableOpacity
        onPress={goBack}
        style={{
          marginTop: 16,
          marginBottom: 8,
          alignSelf: "flex-start",
          padding: 4,
        }}
      >
        <ArrowLeft size={22} color="#6B7280" />
      </TouchableOpacity>

      <View style={{ flex: 1, justifyContent: "center" }}>
        <Text
          style={{
            fontSize: 32,
            fontWeight: "700",
            color: "#111827",
            letterSpacing: -0.5,
            marginBottom: 8,
          }}
        >
          Set up your restaurant
        </Text>
        <Text
          style={{
            fontSize: 14,
            color: "#6B7280",
            marginBottom: 40,
            lineHeight: 22,
          }}
        >
          Enter your restaurant name to get started. You can always change this
          later.
        </Text>

        <View style={{ marginBottom: 24 }}>
          <Text
            style={{
              fontSize: 12,
              fontWeight: "500",
              color: "#6B7280",
              marginBottom: 6,
            }}
          >
            Restaurant Name
          </Text>
          <TextInput
            value={name}
            onChangeText={setName}
            placeholder="e.g. Neo Cafe"
            style={{
              backgroundColor: "#FFFFFF",
              borderWidth: 1,
              borderColor: "#E5E7EB",
              borderRadius: 10,
              padding: 14,
              fontSize: 15,
              color: "#111827",
            }}
            placeholderTextColor="#9CA3AF"
          />
        </View>

        <TouchableOpacity
          onPress={handleSetup}
          disabled={submitting || !name.trim()}
          style={{
            backgroundColor: "#2563EB",
            borderRadius: 10,
            padding: 16,
            alignItems: "center",
            opacity: submitting || !name.trim() ? 0.5 : 1,
          }}
        >
          <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "600" }}>
            {submitting ? "Setting up..." : "Get Started"}
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
