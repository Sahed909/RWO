import { View, Text, TouchableOpacity, Platform } from "react-native";
import { useState, useEffect } from "react";
import { CameraView, useCameraPermissions } from "expo-camera";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { SwitchCamera, ArrowLeftRight } from "lucide-react-native";

export default function ScanScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();
  const [permission, requestPermission] = useCameraPermissions();
  const [scanned, setScanned] = useState(false);

  const handleBarCodeScanned = ({ data }) => {
    if (scanned) return;
    setScanned(true);

    // Only handle URLs that match our order pattern
    if (data && data.includes("/order/")) {
      router.push({ pathname: "/order-view", params: { url: data } });
      setTimeout(() => setScanned(false), 2000);
    } else {
      // Not a valid QR code for this app
      alert(
        "This QR code is not a valid QRMenu order code. Please scan a QRMenu code.",
      );
      setScanned(false);
    }
  };

  const switchMode = async () => {
    await AsyncStorage.removeItem("app_mode");
    router.replace("/mode-select");
  };

  if (!permission) {
    return <View style={{ flex: 1, backgroundColor: "#000" }} />;
  }

  if (!permission.granted) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#111827",
          justifyContent: "center",
          alignItems: "center",
          paddingHorizontal: 32,
          paddingTop: insets.top,
          paddingBottom: insets.bottom,
        }}
      >
        <StatusBar style="light" />
        <Text
          style={{
            fontSize: 24,
            fontWeight: "700",
            color: "#FFFFFF",
            textAlign: "center",
            marginBottom: 12,
          }}
        >
          Camera Access Needed
        </Text>
        <Text
          style={{
            fontSize: 15,
            color: "#9CA3AF",
            textAlign: "center",
            lineHeight: 24,
            marginBottom: 32,
          }}
        >
          We need your camera to scan QR codes at restaurants.
        </Text>
        <TouchableOpacity
          onPress={requestPermission}
          style={{
            backgroundColor: "#2563EB",
            borderRadius: 12,
            paddingVertical: 16,
            paddingHorizontal: 32,
            marginBottom: 16,
          }}
        >
          <Text style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "600" }}>
            Allow Camera
          </Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={switchMode}>
          <Text style={{ color: "#6B7280", fontSize: 14 }}>Switch mode</Text>
        </TouchableOpacity>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#000" }}>
      <StatusBar style="light" />

      {/* Camera */}
      <CameraView
        style={{ flex: 1 }}
        facing="back"
        onBarcodeScanned={handleBarCodeScanned}
        barcodeScannerSettings={{ barcodeTypes: ["qr"] }}
      />

      {/* Overlay */}
      <View
        style={{
          position: "absolute",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          justifyContent: "space-between",
        }}
      >
        {/* Top bar */}
        <View
          style={{
            paddingTop: insets.top + 16,
            paddingHorizontal: 24,
            flexDirection: "row",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Text style={{ fontSize: 20, fontWeight: "700", color: "#FFFFFF" }}>
            Scan to Order
          </Text>
          <TouchableOpacity
            onPress={switchMode}
            style={{
              backgroundColor: "rgba(255,255,255,0.15)",
              borderRadius: 20,
              paddingHorizontal: 14,
              paddingVertical: 7,
              flexDirection: "row",
              alignItems: "center",
              gap: 6,
            }}
          >
            <ArrowLeftRight size={14} color="#FFFFFF" />
            <Text style={{ color: "#FFFFFF", fontSize: 13, fontWeight: "500" }}>
              Switch Mode
            </Text>
          </TouchableOpacity>
        </View>

        {/* Scanner frame in the center */}
        <View style={{ alignItems: "center" }}>
          <View style={{ width: 240, height: 240, position: "relative" }}>
            {/* Corner brackets */}
            {[
              { top: 0, left: 0, borderTopWidth: 3, borderLeftWidth: 3 },
              { top: 0, right: 0, borderTopWidth: 3, borderRightWidth: 3 },
              { bottom: 0, left: 0, borderBottomWidth: 3, borderLeftWidth: 3 },
              {
                bottom: 0,
                right: 0,
                borderBottomWidth: 3,
                borderRightWidth: 3,
              },
            ].map((style, i) => (
              <View
                key={i}
                style={{
                  position: "absolute",
                  width: 36,
                  height: 36,
                  borderColor: "#FFFFFF",
                  borderRadius: 3,
                  ...style,
                }}
              />
            ))}

            {/* Scanned flash */}
            {scanned && (
              <View
                style={{
                  position: "absolute",
                  inset: 0,
                  backgroundColor: "rgba(37,99,235,0.3)",
                  borderRadius: 8,
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Text
                  style={{ color: "#FFFFFF", fontWeight: "700", fontSize: 16 }}
                >
                  ✓ Scanned
                </Text>
              </View>
            )}
          </View>
        </View>

        {/* Bottom hint */}
        <View
          style={{
            paddingBottom: insets.bottom + 40,
            alignItems: "center",
            paddingHorizontal: 32,
          }}
        >
          <Text
            style={{
              color: "rgba(255,255,255,0.8)",
              fontSize: 14,
              textAlign: "center",
              lineHeight: 22,
            }}
          >
            Point your camera at the QR code on the restaurant's table or menu
          </Text>
        </View>
      </View>
    </View>
  );
}
