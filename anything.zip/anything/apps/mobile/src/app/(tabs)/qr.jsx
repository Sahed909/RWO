import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  Alert,
  Share,
  Modal,
  Dimensions,
  TextInput,
  Platform,
} from "react-native";
import { Image } from "expo-image";
import { useState, useEffect } from "react";
import {
  Plus,
  Trash2,
  Share as ShareIcon,
  ArrowLeftRight,
  X,
  QrCode,
  Printer,
} from "lucide-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BottomSheet, {
  BottomSheetScrollView,
  BottomSheetTextInput,
} from "@gorhom/bottom-sheet";
import { useRef, useMemo } from "react";
import { useRouter } from "expo-router";
import * as Linking from "expo-linking";

const SCREEN_WIDTH = Dimensions.get("window").width;
const SheetInput = Platform.OS === "web" ? TextInput : BottomSheetTextInput;

// Module-level cache
let _cachedRestaurantId = null;

export default function QrTab() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [qrs, setQrs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [restaurantId, setRestaurantId] = useState(_cachedRestaurantId);
  const [appUrl, setAppUrl] = useState("");
  const [selectedQr, setSelectedQr] = useState(null); // for full screen

  const bottomSheetRef = useRef(null);
  const snapPoints = useMemo(() => ["60%"], []);
  const [generating, setGenerating] = useState(false);

  // Form state for new QR
  const [qrLabel, setQrLabel] = useState("");
  const [qrType, setQrType] = useState("permanent"); // "permanent" | "time_based"
  const [expiryHours, setExpiryHours] = useState("");

  useEffect(() => {
    const baseUrl =
      process.env.EXPO_PUBLIC_BASE_URL ||
      process.env.EXPO_PUBLIC_PROXY_BASE_URL ||
      "";
    setAppUrl(baseUrl);
    loadData();
  }, []);

  const loadData = async () => {
    try {
      let id = _cachedRestaurantId;
      if (!id) {
        id = await AsyncStorage.getItem("restaurant_id");
        _cachedRestaurantId = id;
      }
      if (id) {
        setRestaurantId(id);
        const res = await fetch(`/api/qr-codes?restaurant_id=${id}`);
        const data = await res.json();
        setQrs(data || []);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  };

  const openSheet = () => {
    setQrLabel("");
    setQrType("permanent");
    setExpiryHours("");
    bottomSheetRef.current?.expand();
  };

  const createQr = async () => {
    if (!qrLabel.trim()) {
      alert("Please enter a name for this QR code.");
      return;
    }
    if (qrType === "time_based") {
      const hrs = parseFloat(expiryHours);
      if (!expiryHours || isNaN(hrs) || hrs <= 0) {
        alert("Please enter a valid number of hours for expiry.");
        return;
      }
    }
    setGenerating(true);
    try {
      await fetch("/api/qr-codes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          restaurant_id: restaurantId,
          type: qrType,
          expires_in_hours:
            qrType === "time_based" ? parseFloat(expiryHours) : null,
          label: qrLabel.trim(),
        }),
      });
      bottomSheetRef.current?.close();
      loadData();
    } catch (e) {
      alert("Error generating QR");
    } finally {
      setGenerating(false);
    }
  };

  const deleteQr = async (id) => {
    Alert.alert(
      "Delete QR Code",
      "Are you sure you want to delete this QR code? Customers won't be able to scan it anymore.",
      [
        { text: "Cancel", style: "cancel" },
        {
          text: "Delete",
          style: "destructive",
          onPress: async () => {
            try {
              await fetch(`/api/qr-codes/${id}`, { method: "DELETE" });
              if (selectedQr?.id === id) setSelectedQr(null);
              loadData();
            } catch (e) {
              alert("Error deleting QR code");
            }
          },
        },
      ],
    );
  };

  const shareLink = async (qrId) => {
    try {
      const url = `${appUrl}/order/${qrId}`;
      await Share.share({ message: `Order from our menu here: ${url}` });
    } catch (error) {
      console.log(error);
    }
  };

  const printQr = async (qrId) => {
    const url = `${appUrl}/api/print-qr/${qrId}`;
    await Linking.openURL(url);
  };

  const switchMode = async () => {
    await AsyncStorage.removeItem("app_mode");
    router.replace("/mode-select");
  };

  const getQrImageUrl = (qrId, size = 250) =>
    `https://api.qrserver.com/v1/create-qr-code/?size=${size}x${size}&margin=10&data=${encodeURIComponent(`${appUrl}/order/${qrId}`)}`;

  const renderStatus = (qr) => {
    if (!qr.is_active) {
      return { label: "Inactive", color: "#6B7280", dot: "#6B7280" };
    }
    if (qr.type === "time_based") {
      const expired = new Date(qr.expires_at) < new Date();
      if (expired)
        return { label: "Expired", color: "#EF4444", dot: "#EF4444" };
      return { label: "Active · Temp", color: "#F59E0B", dot: "#F59E0B" };
    }
    return { label: "Active", color: "#10B981", dot: "#10B981" };
  };

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#FFFFFF",
          justifyContent: "center",
        }}
      >
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <View
      style={{ flex: 1, backgroundColor: "#FFFFFF", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          paddingHorizontal: 24,
          paddingVertical: 16,
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={{ fontSize: 24, fontWeight: "600", color: "#111827" }}>
          QR Codes
        </Text>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <TouchableOpacity
            onPress={switchMode}
            style={{
              borderWidth: 1,
              borderColor: "#E5E7EB",
              borderRadius: 999,
              paddingHorizontal: 10,
              paddingVertical: 6,
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
            }}
          >
            <ArrowLeftRight size={13} color="#6B7280" />
            <Text style={{ color: "#6B7280", fontSize: 12, fontWeight: "500" }}>
              Switch
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={openSheet}
            style={{
              backgroundColor: "#EFF6FF",
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 999,
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
            }}
          >
            <Plus size={16} color="#2563EB" />
            <Text style={{ color: "#2563EB", fontSize: 14, fontWeight: "500" }}>
              Generate QR
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* QR List */}
      <ScrollView
        style={{ flex: 1, backgroundColor: "#F9FAFB" }}
        contentContainerStyle={{ padding: 20, gap: 14 }}
      >
        {qrs.length === 0 ? (
          <View style={{ alignItems: "center", marginTop: 60 }}>
            <QrCode size={48} color="#D1D5DB" />
            <Text
              style={{
                color: "#6B7280",
                fontSize: 14,
                textAlign: "center",
                marginTop: 16,
              }}
            >
              No QR codes yet.{"\n"}Generate one so customers can view your
              menu.
            </Text>
          </View>
        ) : (
          qrs.map((qr) => {
            const status = renderStatus(qr);
            return (
              <TouchableOpacity
                key={qr.id}
                onPress={() => setSelectedQr(qr)}
                activeOpacity={0.8}
                style={{
                  backgroundColor: "#FFFFFF",
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 16,
                  padding: 16,
                  flexDirection: "row",
                  gap: 16,
                  alignItems: "center",
                }}
              >
                {/* QR thumbnail */}
                <View
                  style={{
                    width: 80,
                    height: 80,
                    borderRadius: 10,
                    backgroundColor: "#F9FAFB",
                    borderWidth: 1,
                    borderColor: "#E5E7EB",
                    overflow: "hidden",
                    justifyContent: "center",
                    alignItems: "center",
                  }}
                >
                  <Image
                    source={{ uri: getQrImageUrl(qr.id, 160) }}
                    style={{ width: 80, height: 80 }}
                    contentFit="cover"
                  />
                </View>

                {/* Info */}
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 16,
                      fontWeight: "600",
                      color: "#111827",
                      marginBottom: 6,
                    }}
                  >
                    {qr.label}
                  </Text>

                  {/* Status pill */}
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 5,
                      marginBottom: 12,
                    }}
                  >
                    <View
                      style={{
                        width: 6,
                        height: 6,
                        borderRadius: 3,
                        backgroundColor: status.dot,
                      }}
                    />
                    <Text
                      style={{
                        fontSize: 12,
                        color: status.color,
                        fontWeight: "500",
                      }}
                    >
                      {status.label}
                    </Text>
                  </View>

                  {/* Actions */}
                  <View style={{ flexDirection: "row", gap: 8 }}>
                    <TouchableOpacity
                      onPress={() => shareLink(qr.id)}
                      style={{
                        borderWidth: 1,
                        borderColor: "#E5E7EB",
                        borderRadius: 999,
                        paddingHorizontal: 12,
                        paddingVertical: 5,
                        flexDirection: "row",
                        alignItems: "center",
                        gap: 4,
                      }}
                    >
                      <ShareIcon size={12} color="#6B7280" />
                      <Text
                        style={{
                          fontSize: 12,
                          color: "#6B7280",
                          fontWeight: "500",
                        }}
                      >
                        Share
                      </Text>
                    </TouchableOpacity>

                    <TouchableOpacity
                      onPress={() => deleteQr(qr.id)}
                      style={{
                        borderWidth: 1,
                        borderColor: "#FEE2E2",
                        borderRadius: 999,
                        paddingHorizontal: 12,
                        paddingVertical: 5,
                        flexDirection: "row",
                        alignItems: "center",
                        gap: 4,
                      }}
                    >
                      <Trash2 size={12} color="#EF4444" />
                      <Text
                        style={{
                          fontSize: 12,
                          color: "#EF4444",
                          fontWeight: "500",
                        }}
                      >
                        Delete
                      </Text>
                    </TouchableOpacity>
                  </View>
                </View>

                {/* Tap hint */}
                <Text style={{ fontSize: 11, color: "#D1D5DB" }}>
                  Tap to{"\n"}expand
                </Text>
              </TouchableOpacity>
            );
          })
        )}
      </ScrollView>

      {/* ===== FULL SCREEN QR MODAL ===== */}
      <Modal
        visible={!!selectedQr}
        animationType="fade"
        transparent
        onRequestClose={() => setSelectedQr(null)}
      >
        <View
          style={{
            flex: 1,
            backgroundColor: "rgba(0,0,0,0.92)",
            justifyContent: "center",
            alignItems: "center",
            paddingHorizontal: 24,
            paddingTop: insets.top,
            paddingBottom: insets.bottom,
          }}
        >
          {/* Close */}
          <TouchableOpacity
            onPress={() => setSelectedQr(null)}
            style={{
              position: "absolute",
              top: insets.top + 16,
              right: 24,
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: "rgba(255,255,255,0.15)",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <X size={20} color="#FFFFFF" />
          </TouchableOpacity>

          {selectedQr && (
            <>
              {/* Label + status */}
              <Text
                style={{
                  fontSize: 22,
                  fontWeight: "700",
                  color: "#FFFFFF",
                  marginBottom: 6,
                  textAlign: "center",
                }}
              >
                {selectedQr.label}
              </Text>
              <View
                style={{
                  flexDirection: "row",
                  alignItems: "center",
                  gap: 6,
                  marginBottom: 36,
                }}
              >
                <View
                  style={{
                    width: 7,
                    height: 7,
                    borderRadius: 4,
                    backgroundColor: renderStatus(selectedQr).dot,
                  }}
                />
                <Text
                  style={{
                    fontSize: 13,
                    color: "rgba(255,255,255,0.7)",
                    fontWeight: "500",
                  }}
                >
                  {renderStatus(selectedQr).label}
                </Text>
              </View>

              {/* Big QR code */}
              <View
                style={{
                  backgroundColor: "#FFFFFF",
                  borderRadius: 20,
                  padding: 20,
                  marginBottom: 36,
                }}
              >
                <Image
                  source={{ uri: getQrImageUrl(selectedQr.id, 600) }}
                  style={{
                    width: SCREEN_WIDTH - 112,
                    height: SCREEN_WIDTH - 112,
                  }}
                  contentFit="contain"
                />
              </View>

              {/* Instructions */}
              <Text
                style={{
                  fontSize: 14,
                  color: "rgba(255,255,255,0.6)",
                  textAlign: "center",
                  marginBottom: 28,
                  lineHeight: 22,
                }}
              >
                Show this QR code to your customers.{"\n"}They scan it to view
                your menu and order.
              </Text>

              {/* Share + Print buttons */}
              <View style={{ flexDirection: "row", gap: 12, width: "100%" }}>
                <TouchableOpacity
                  onPress={() => shareLink(selectedQr.id)}
                  style={{
                    flex: 1,
                    backgroundColor: "#2563EB",
                    borderRadius: 14,
                    paddingVertical: 14,
                    paddingHorizontal: 20,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                  }}
                >
                  <ShareIcon size={18} color="#FFFFFF" />
                  <Text
                    style={{
                      color: "#FFFFFF",
                      fontSize: 15,
                      fontWeight: "600",
                    }}
                  >
                    Share Link
                  </Text>
                </TouchableOpacity>

                <TouchableOpacity
                  onPress={() => printQr(selectedQr.id)}
                  style={{
                    backgroundColor: "rgba(255,255,255,0.18)",
                    borderRadius: 14,
                    paddingVertical: 14,
                    paddingHorizontal: 20,
                    flexDirection: "row",
                    alignItems: "center",
                    justifyContent: "center",
                    gap: 8,
                  }}
                >
                  <Printer size={18} color="#FFFFFF" />
                  <Text
                    style={{
                      color: "#FFFFFF",
                      fontSize: 15,
                      fontWeight: "600",
                    }}
                  >
                    Print
                  </Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </View>
      </Modal>

      {/* Generate QR Bottom Sheet */}
      <BottomSheet
        ref={bottomSheetRef}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backgroundStyle={{
          backgroundColor: "#FFFFFF",
          borderWidth: 1,
          borderColor: "#E5E7EB",
        }}
      >
        <BottomSheetScrollView style={{ flex: 1, padding: 24 }}>
          <Text
            style={{
              fontSize: 20,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 24,
            }}
          >
            Generate New QR Code
          </Text>
          <View style={{ gap: 12 }}>
            {/* QR Name */}
            <View>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#6B7280",
                  marginBottom: 8,
                }}
              >
                QR Name *
              </Text>
              <SheetInput
                value={qrLabel}
                onChangeText={setQrLabel}
                style={{
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 10,
                  padding: 13,
                  fontSize: 14,
                  color: "#111827",
                }}
                placeholder="e.g. Table 4, Takeaway Counter"
              />
            </View>

            {/* Type toggle */}
            <View>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#6B7280",
                  marginBottom: 8,
                }}
              >
                Expiry
              </Text>
              <View style={{ flexDirection: "row", gap: 10 }}>
                <TouchableOpacity
                  onPress={() => setQrType("permanent")}
                  style={{
                    flex: 1,
                    backgroundColor:
                      qrType === "permanent" ? "#EFF6FF" : "#FFFFFF",
                    borderRadius: 14,
                    padding: 16,
                    alignItems: "center",
                  }}
                >
                  <Text
                    style={{
                      color: qrType === "permanent" ? "#1D4ED8" : "#111827",
                      fontSize: 14,
                      fontWeight: "600",
                    }}
                  >
                    Permanent
                  </Text>
                </TouchableOpacity>
                <TouchableOpacity
                  onPress={() => setQrType("time_based")}
                  style={{
                    flex: 1,
                    backgroundColor:
                      qrType === "time_based" ? "#EFF6FF" : "#FFFFFF",
                    borderRadius: 14,
                    padding: 16,
                    alignItems: "center",
                  }}
                >
                  <Text
                    style={{
                      color: qrType === "time_based" ? "#1D4ED8" : "#111827",
                      fontSize: 14,
                      fontWeight: "600",
                    }}
                  >
                    Custom
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {qrType === "time_based" && (
              <View>
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "500",
                    color: "#6B7280",
                    marginBottom: 8,
                  }}
                >
                  Hours
                </Text>
                <SheetInput
                  value={expiryHours}
                  onChangeText={setExpiryHours}
                  style={{
                    borderWidth: 1,
                    borderColor: "#E5E7EB",
                    borderRadius: 10,
                    padding: 13,
                    fontSize: 14,
                    color: "#111827",
                  }}
                  placeholder="e.g. 2, 24"
                />
              </View>
            )}

            <TouchableOpacity
              onPress={createQr}
              disabled={generating}
              style={{
                padding: 18,
                borderWidth: 1.5,
                borderColor: "#2563EB",
                borderRadius: 14,
                backgroundColor: "#EFF6FF",
              }}
            >
              <Text
                style={{
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#1D4ED8",
                  marginBottom: 4,
                }}
              >
                Generate QR
              </Text>
            </TouchableOpacity>

            {generating && (
              <View style={{ alignItems: "center", paddingTop: 8 }}>
                <ActivityIndicator color="#2563EB" />
              </View>
            )}
          </View>
        </BottomSheetScrollView>
      </BottomSheet>
    </View>
  );
}
