import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  ActivityIndicator,
  RefreshControl,
  Animated,
} from "react-native";
import { useState, useEffect, useRef, useCallback } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ArrowLeftRight, Printer } from "lucide-react-native";
import { useRouter } from "expo-router";
import * as Linking from "expo-linking";

let _cachedRestaurantId = null;

const BASE_URL =
  process.env.EXPO_PUBLIC_BASE_URL ||
  process.env.EXPO_PUBLIC_PROXY_BASE_URL ||
  "";

export default function OrdersTab() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Map of orderId → Animated.Value for opacity
  const opacityMap = useRef({});

  const getOpacity = useCallback((order) => {
    if (!opacityMap.current[order.id]) {
      // Start completed orders already dimmed, others at full opacity
      opacityMap.current[order.id] = new Animated.Value(
        order.status === "completed" ? 0.35 : 1,
      );
    }
    return opacityMap.current[order.id];
  }, []);

  const animateComplete = useCallback((orderId) => {
    const anim = opacityMap.current[orderId];
    if (anim) {
      Animated.timing(anim, {
        toValue: 0.35,
        duration: 600,
        useNativeDriver: true,
      }).start();
    }
  }, []);

  const animateRestore = useCallback((orderId) => {
    const anim = opacityMap.current[orderId];
    if (anim) {
      Animated.timing(anim, {
        toValue: 1,
        duration: 300,
        useNativeDriver: true,
      }).start();
    }
  }, []);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    try {
      let id = _cachedRestaurantId;
      if (!id) {
        id = await AsyncStorage.getItem("restaurant_id");
        _cachedRestaurantId = id;
      }
      if (id) {
        const res = await fetch(`/api/orders?restaurant_id=${id}`);
        const data = await res.json();
        const newOrders = data || [];

        // Sync animation values for any newly completed orders
        newOrders.forEach((order) => {
          if (!opacityMap.current[order.id]) {
            opacityMap.current[order.id] = new Animated.Value(
              order.status === "completed" ? 0.35 : 1,
            );
          }
        });

        setOrders(newOrders);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  const onRefresh = () => {
    setRefreshing(true);
    loadData();
  };

  const updateStatus = async (order, status) => {
    try {
      // Optimistic local update first
      setOrders((prev) =>
        prev.map((o) => (o.id === order.id ? { ...o, status } : o)),
      );
      // Animate if completing
      if (status === "completed") {
        animateComplete(order.id);
      } else {
        animateRestore(order.id);
      }

      await fetch(`/api/orders/${order.id}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
    } catch (e) {
      alert("Error updating order");
      loadData(); // revert on failure
    }
  };

  const printOrder = async (orderId) => {
    const url = `${BASE_URL}/api/print-order/${orderId}`;
    await Linking.openURL(url);
  };

  const switchMode = async () => {
    await AsyncStorage.removeItem("app_mode");
    router.replace("/mode-select");
  };

  const statusConfig = {
    pending: { label: "Pending", color: "#6B7280" },
    in_progress: { label: "Preparing", color: "#F59E0B" },
    ready: { label: "Ready", color: "#10B981" },
    completed: { label: "Completed", color: "#2563EB" },
  };

  const renderStatusBar = (order) => {
    const steps = ["pending", "in_progress", "ready", "completed"];
    return (
      <View
        style={{
          flexDirection: "row",
          gap: 6,
          flexWrap: "wrap",
          paddingTop: 14,
          borderTopWidth: 1,
          borderTopColor: "#E5E7EB",
        }}
      >
        {steps.map((s) => {
          const cfg = statusConfig[s];
          const isActive = order.status === s;
          return (
            <TouchableOpacity
              key={s}
              onPress={() => !isActive && updateStatus(order, s)}
              style={{
                paddingHorizontal: 12,
                paddingVertical: 6,
                borderRadius: 999,
                borderWidth: 1,
                borderColor: isActive ? cfg.color : "#E5E7EB",
                backgroundColor: isActive ? cfg.color + "18" : "#FFFFFF",
              }}
            >
              <Text
                style={{
                  fontSize: 12,
                  color: isActive ? cfg.color : "#9CA3AF",
                  fontWeight: isActive ? "700" : "500",
                }}
              >
                {cfg.label}
              </Text>
            </TouchableOpacity>
          );
        })}
      </View>
    );
  };

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#FFFFFF",
          justifyContent: "center",
        }}
      >
        <ActivityIndicator />
      </View>
    );
  }

  return (
    <View
      style={{ flex: 1, backgroundColor: "#FFFFFF", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          paddingHorizontal: 24,
          paddingVertical: 16,
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={{ fontSize: 24, fontWeight: "600", color: "#111827" }}>
          Live Orders
        </Text>
        <TouchableOpacity
          onPress={switchMode}
          style={{
            borderWidth: 1,
            borderColor: "#E5E7EB",
            borderRadius: 999,
            paddingHorizontal: 10,
            paddingVertical: 6,
            flexDirection: "row",
            alignItems: "center",
            gap: 4,
          }}
        >
          <ArrowLeftRight size={13} color="#6B7280" />
          <Text style={{ color: "#6B7280", fontSize: 12, fontWeight: "500" }}>
            Switch
          </Text>
        </TouchableOpacity>
      </View>

      <ScrollView
        style={{ flex: 1, backgroundColor: "#F9FAFB" }}
        contentContainerStyle={{ padding: 20, gap: 14 }}
        refreshControl={
          <RefreshControl refreshing={refreshing} onRefresh={onRefresh} />
        }
      >
        {orders.length === 0 ? (
          <Text
            style={{
              color: "#6B7280",
              fontSize: 14,
              textAlign: "center",
              marginTop: 40,
            }}
          >
            No orders yet. Pull to refresh.
          </Text>
        ) : (
          orders.map((order) => {
            const opacity = getOpacity(order);
            return (
              <Animated.View
                key={order.id}
                style={{
                  opacity,
                  backgroundColor: "#FFFFFF",
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 14,
                  padding: 16,
                  marginBottom: 2,
                }}
              >
                {/* Top row: name + time + total + print */}
                <View
                  style={{
                    flexDirection: "row",
                    justifyContent: "space-between",
                    alignItems: "flex-start",
                    marginBottom: 12,
                  }}
                >
                  <View style={{ flex: 1 }}>
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: "600",
                        color: "#111827",
                      }}
                    >
                      {order.customer_name}
                    </Text>
                    <Text
                      style={{ fontSize: 12, color: "#6B7280", marginTop: 2 }}
                    >
                      {new Date(order.created_at).toLocaleTimeString([], {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </Text>
                  </View>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      gap: 12,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 16,
                        fontWeight: "700",
                        color: "#111827",
                      }}
                    >
                      ৳{Number(order.total).toFixed(0)}
                    </Text>
                    <TouchableOpacity
                      onPress={() => printOrder(order.id)}
                      style={{
                        width: 34,
                        height: 34,
                        borderRadius: 8,
                        backgroundColor: "#F3F4F6",
                        justifyContent: "center",
                        alignItems: "center",
                      }}
                    >
                      <Printer size={16} color="#374151" />
                    </TouchableOpacity>
                  </View>
                </View>

                {/* Items */}
                <View style={{ marginBottom: 12, gap: 3 }}>
                  {order.items?.map((item) => (
                    <View
                      key={item.id}
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                      }}
                    >
                      <Text style={{ fontSize: 13, color: "#4B5563" }}>
                        {item.quantity}× {item.item_name}
                      </Text>
                      <Text style={{ fontSize: 13, color: "#6B7280" }}>
                        ৳{Number(item.subtotal).toFixed(0)}
                      </Text>
                    </View>
                  ))}
                </View>

                {/* Notes */}
                {order.notes ? (
                  <View
                    style={{
                      backgroundColor: "#FFFBEB",
                      padding: 10,
                      borderRadius: 8,
                      marginBottom: 12,
                    }}
                  >
                    <Text
                      style={{
                        fontSize: 12,
                        fontWeight: "500",
                        color: "#92400E",
                      }}
                    >
                      Note: {order.notes}
                    </Text>
                  </View>
                ) : null}

                {/* Status buttons */}
                {renderStatusBar(order)}
              </Animated.View>
            );
          })
        )}
      </ScrollView>
    </View>
  );
}
