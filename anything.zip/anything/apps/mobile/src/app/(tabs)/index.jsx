import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  TextInput,
  ActivityIndicator,
  Platform,
} from "react-native";
import { useState, useEffect, useRef, useMemo } from "react";
import {
  Plus,
  Edit2,
  Trash2,
  ArrowLeftRight,
  Eye,
  EyeOff,
} from "lucide-react-native";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import BottomSheet, {
  BottomSheetScrollView,
  BottomSheetTextInput,
} from "@gorhom/bottom-sheet";
import { useRouter } from "expo-router";

const SheetInput = Platform.OS === "web" ? TextInput : BottomSheetTextInput;

// Module-level cache — survives tab switches, avoids repeated AsyncStorage calls
let _cachedRestaurantId = null;

export default function MenuTab() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [restaurantId, setRestaurantId] = useState(_cachedRestaurantId);
  const [togglingId, setTogglingId] = useState(null);

  const bottomSheetRef = useRef(null);
  const snapPoints = useMemo(() => ["75%"], []);
  const [editingItem, setEditingItem] = useState(null);

  const [form, setForm] = useState({
    name: "",
    quantity: "1",
    price: "",
    description: "",
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      let id = _cachedRestaurantId;
      if (!id) {
        id = await AsyncStorage.getItem("restaurant_id");
        _cachedRestaurantId = id;
      }
      if (id) {
        setRestaurantId(id);
        const res = await fetch(`/api/menu-items?restaurant_id=${id}`);
        const data = await res.json();
        setItems(data || []);
      }
    } catch (e) {
      console.log(e);
    } finally {
      setLoading(false);
    }
  };

  const openForm = (item = null) => {
    if (item) {
      setEditingItem(item);
      setForm({
        name: item.name,
        quantity: item.quantity?.toString() || "1",
        price: item.price.toString(),
        description: item.description || "",
      });
    } else {
      setEditingItem(null);
      setForm({ name: "", quantity: "1", price: "", description: "" });
    }
    bottomSheetRef.current?.expand();
  };

  const closeForm = () => bottomSheetRef.current?.close();

  const saveItem = async () => {
    if (!form.name || !form.price) return;
    try {
      const payload = {
        restaurant_id: restaurantId,
        name: form.name,
        quantity: parseInt(form.quantity || "1", 10),
        price: parseFloat(form.price),
        description: form.description,
      };
      if (editingItem) {
        payload.id = editingItem.id;
        await fetch("/api/menu-items", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      } else {
        await fetch("/api/menu-items", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload),
        });
      }
      closeForm();
      loadData();
    } catch (e) {
      alert("Error saving item");
    }
  };

  const deleteItem = async (id) => {
    try {
      await fetch(`/api/menu-items?id=${id}`, { method: "DELETE" });
      loadData();
    } catch (e) {
      alert("Error deleting item");
    }
  };

  // Toggle item available/unavailable (list / release from list)
  const toggleAvailability = async (item) => {
    setTogglingId(item.id);
    try {
      await fetch("/api/menu-items", {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ id: item.id, is_available: !item.is_available }),
      });
      // Optimistically update local state
      setItems((prev) =>
        prev.map((i) =>
          i.id === item.id ? { ...i, is_available: !i.is_available } : i,
        ),
      );
    } catch (e) {
      alert("Error updating item");
    } finally {
      setTogglingId(null);
    }
  };

  const switchMode = async () => {
    await AsyncStorage.removeItem("app_mode");
    router.replace("/mode-select");
  };

  if (loading) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#FFFFFF",
          justifyContent: "center",
        }}
      >
        <ActivityIndicator />
      </View>
    );
  }

  // Group items by category
  const categories = [...new Set(items.map((i) => i.category || "General"))];

  return (
    <View
      style={{ flex: 1, backgroundColor: "#FFFFFF", paddingTop: insets.top }}
    >
      {/* Header */}
      <View
        style={{
          paddingHorizontal: 24,
          paddingVertical: 16,
          borderBottomWidth: 1,
          borderBottomColor: "#E5E7EB",
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={{ fontSize: 24, fontWeight: "600", color: "#111827" }}>
          Menu
        </Text>
        <View style={{ flexDirection: "row", alignItems: "center", gap: 10 }}>
          <TouchableOpacity
            onPress={switchMode}
            style={{
              borderWidth: 1,
              borderColor: "#E5E7EB",
              borderRadius: 999,
              paddingHorizontal: 10,
              paddingVertical: 6,
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
            }}
          >
            <ArrowLeftRight size={13} color="#6B7280" />
            <Text style={{ color: "#6B7280", fontSize: 12, fontWeight: "500" }}>
              Switch
            </Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={() => openForm()}
            style={{
              backgroundColor: "#EFF6FF",
              paddingHorizontal: 12,
              paddingVertical: 6,
              borderRadius: 999,
              flexDirection: "row",
              alignItems: "center",
              gap: 4,
            }}
          >
            <Plus size={16} color="#2563EB" />
            <Text style={{ color: "#2563EB", fontSize: 14, fontWeight: "500" }}>
              Add Item
            </Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Item list */}
      <ScrollView
        style={{ flex: 1, backgroundColor: "#F9FAFB" }}
        contentContainerStyle={{ padding: 20, gap: 8 }}
      >
        {items.length === 0 ? (
          <Text
            style={{
              color: "#6B7280",
              fontSize: 14,
              textAlign: "center",
              marginTop: 40,
            }}
          >
            No menu items yet. Add your first dish!
          </Text>
        ) : (
          categories.map((category) => (
            <View key={category} style={{ marginBottom: 8 }}>
              {/* Category label */}
              <View style={{ paddingHorizontal: 4, paddingVertical: 8 }}>
                <Text
                  style={{
                    fontSize: 12,
                    fontWeight: "600",
                    color: "#6B7280",
                    textTransform: "uppercase",
                    letterSpacing: 0.8,
                  }}
                >
                  {category}
                </Text>
              </View>

              {/* Items in this category */}
              {items
                .filter((i) => (i.category || "General") === category)
                .map((item) => (
                  <View
                    key={item.id}
                    style={{
                      backgroundColor: item.is_available
                        ? "#FFFFFF"
                        : "#F9FAFB",
                      borderWidth: 1,
                      borderColor: item.is_available ? "#E5E7EB" : "#E5E7EB",
                      borderRadius: 12,
                      padding: 16,
                      marginBottom: 8,
                      opacity: item.is_available ? 1 : 0.65,
                    }}
                  >
                    <View
                      style={{
                        flexDirection: "row",
                        justifyContent: "space-between",
                        alignItems: "flex-start",
                      }}
                    >
                      <View style={{ flex: 1, marginRight: 12 }}>
                        <View
                          style={{
                            flexDirection: "row",
                            alignItems: "center",
                            gap: 8,
                            marginBottom: 2,
                          }}
                        >
                          <Text
                            style={{
                              fontSize: 15,
                              fontWeight: "600",
                              color: "#111827",
                            }}
                          >
                            {item.name}
                          </Text>
                          {!item.is_available && (
                            <View
                              style={{
                                backgroundColor: "#FEE2E2",
                                borderRadius: 999,
                                paddingHorizontal: 8,
                                paddingVertical: 2,
                              }}
                            >
                              <Text
                                style={{
                                  fontSize: 10,
                                  fontWeight: "600",
                                  color: "#DC2626",
                                }}
                              >
                                OFF MENU
                              </Text>
                            </View>
                          )}
                        </View>
                        {item.description ? (
                          <Text
                            style={{
                              fontSize: 13,
                              color: "#6B7280",
                              marginTop: 2,
                              lineHeight: 18,
                            }}
                          >
                            {item.description}
                          </Text>
                        ) : null}
                        <Text
                          style={{
                            fontSize: 14,
                            fontWeight: "600",
                            color: "#111827",
                            marginTop: 8,
                          }}
                        >
                          ৳{Number(item.price).toFixed(0)}
                        </Text>
                      </View>

                      {/* Action buttons */}
                      <View
                        style={{
                          flexDirection: "column",
                          gap: 10,
                          alignItems: "flex-end",
                        }}
                      >
                        <View style={{ flexDirection: "row", gap: 14 }}>
                          <TouchableOpacity onPress={() => openForm(item)}>
                            <Edit2 size={17} color="#9CA3AF" />
                          </TouchableOpacity>
                          <TouchableOpacity onPress={() => deleteItem(item.id)}>
                            <Trash2 size={17} color="#EF4444" />
                          </TouchableOpacity>
                        </View>

                        {/* List / Release toggle */}
                        <TouchableOpacity
                          onPress={() => toggleAvailability(item)}
                          disabled={togglingId === item.id}
                          style={{
                            flexDirection: "row",
                            alignItems: "center",
                            gap: 5,
                            paddingHorizontal: 10,
                            paddingVertical: 5,
                            borderRadius: 999,
                            borderWidth: 1,
                            borderColor: item.is_available
                              ? "#D1FAE5"
                              : "#E5E7EB",
                            backgroundColor: item.is_available
                              ? "#ECFDF5"
                              : "#F3F4F6",
                          }}
                        >
                          {togglingId === item.id ? (
                            <ActivityIndicator size="small" color="#6B7280" />
                          ) : item.is_available ? (
                            <>
                              <Eye size={12} color="#059669" />
                              <Text
                                style={{
                                  fontSize: 11,
                                  fontWeight: "600",
                                  color: "#059669",
                                }}
                              >
                                Listed
                              </Text>
                            </>
                          ) : (
                            <>
                              <EyeOff size={12} color="#6B7280" />
                              <Text
                                style={{
                                  fontSize: 11,
                                  fontWeight: "600",
                                  color: "#6B7280",
                                }}
                              >
                                Hidden
                              </Text>
                            </>
                          )}
                        </TouchableOpacity>
                      </View>
                    </View>
                  </View>
                ))}
            </View>
          ))
        )}
      </ScrollView>

      {/* Add / Edit Item Bottom Sheet */}
      <BottomSheet
        ref={bottomSheetRef}
        index={-1}
        snapPoints={snapPoints}
        enablePanDownToClose
        backgroundStyle={{
          backgroundColor: "#FFFFFF",
          borderWidth: 1,
          borderColor: "#E5E7EB",
        }}
      >
        <BottomSheetScrollView style={{ flex: 1, padding: 24 }}>
          <Text
            style={{
              fontSize: 20,
              fontWeight: "600",
              color: "#111827",
              marginBottom: 24,
            }}
          >
            {editingItem ? "Edit Item" : "Add Menu Item"}
          </Text>

          <View style={{ gap: 16, marginBottom: 40 }}>
            <View>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#6B7280",
                  marginBottom: 6,
                }}
              >
                Name *
              </Text>
              <SheetInput
                value={form.name}
                onChangeText={(t) => setForm({ ...form, name: t })}
                style={{
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 14,
                  color: "#111827",
                }}
                placeholder="Item Name"
              />
            </View>
            <View>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#6B7280",
                  marginBottom: 6,
                }}
              >
                Quantity
              </Text>
              <SheetInput
                value={form.quantity}
                onChangeText={(t) => setForm({ ...form, quantity: t })}
                keyboardType="number-pad"
                style={{
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 14,
                  color: "#111827",
                }}
                placeholder="1"
              />
            </View>
            <View>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#6B7280",
                  marginBottom: 6,
                }}
              >
                Price (BDT) *
              </Text>
              <SheetInput
                value={form.price}
                onChangeText={(t) => setForm({ ...form, price: t })}
                keyboardType="decimal-pad"
                style={{
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 14,
                  color: "#111827",
                }}
                placeholder="0.00"
              />
            </View>
            <View>
              <Text
                style={{
                  fontSize: 12,
                  fontWeight: "500",
                  color: "#6B7280",
                  marginBottom: 6,
                }}
              >
                Description
              </Text>
              <SheetInput
                value={form.description}
                onChangeText={(t) => setForm({ ...form, description: t })}
                multiline
                style={{
                  borderWidth: 1,
                  borderColor: "#E5E7EB",
                  borderRadius: 8,
                  padding: 12,
                  fontSize: 14,
                  color: "#111827",
                  height: 80,
                }}
                placeholder="Short description..."
              />
            </View>
            <TouchableOpacity
              onPress={saveItem}
              style={{
                backgroundColor: "#2563EB",
                borderRadius: 10,
                padding: 15,
                alignItems: "center",
                marginTop: 8,
              }}
            >
              <Text
                style={{ color: "#FFFFFF", fontSize: 15, fontWeight: "600" }}
              >
                Save Item
              </Text>
            </TouchableOpacity>
          </View>
        </BottomSheetScrollView>
      </BottomSheet>
    </View>
  );
}
