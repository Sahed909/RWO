import { View, Text, TouchableOpacity, ActivityIndicator } from "react-native";
import { useState, useEffect } from "react";
import AsyncStorage from "@react-native-async-storage/async-storage";
import { useRouter } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { ShoppingBag, UtensilsCrossed } from "lucide-react-native";
import { StatusBar } from "expo-status-bar";

export default function ModeSelectScreen() {
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const selectMode = async (mode) => {
    await AsyncStorage.setItem("app_mode", mode);
    if (mode === "order") {
      router.replace("/scan");
    } else {
      const restaurantId = await AsyncStorage.getItem("restaurant_id");
      if (restaurantId) {
        router.replace("/(tabs)");
      } else {
        router.replace("/setup");
      }
    }
  };

  return (
    <View
      style={{
        flex: 1,
        backgroundColor: "#FFFFFF",
        paddingTop: insets.top + 20,
        paddingBottom: insets.bottom + 20,
        paddingHorizontal: 24,
      }}
    >
      <StatusBar style="dark" />
      <View style={{ flex: 1, justifyContent: "center" }}>
        <View style={{ marginBottom: 48 }}>
          <Text
            style={{
              fontSize: 38,
              fontWeight: "700",
              color: "#111827",
              letterSpacing: -1,
              marginBottom: 10,
            }}
          >
            QRMenu
          </Text>
          <Text style={{ fontSize: 16, color: "#6B7280", lineHeight: 24 }}>
            How would you like to use the app today?
          </Text>
        </View>

        <View style={{ gap: 16 }}>
          {/* Order Mode */}
          <TouchableOpacity
            onPress={() => selectMode("order")}
            activeOpacity={0.85}
            style={{
              backgroundColor: "#2563EB",
              borderRadius: 20,
              padding: 28,
              flexDirection: "row",
              alignItems: "center",
              gap: 20,
            }}
          >
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: 14,
                backgroundColor: "rgba(255,255,255,0.2)",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <ShoppingBag size={28} color="#FFFFFF" />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontSize: 20,
                  fontWeight: "700",
                  color: "#FFFFFF",
                  marginBottom: 4,
                }}
              >
                I want to order
              </Text>
              <Text
                style={{
                  fontSize: 14,
                  color: "rgba(255,255,255,0.75)",
                  lineHeight: 20,
                }}
              >
                Scan a QR code at a restaurant and browse the menu
              </Text>
            </View>
          </TouchableOpacity>

          {/* Restaurant Mode */}
          <TouchableOpacity
            onPress={() => selectMode("restaurant")}
            activeOpacity={0.85}
            style={{
              backgroundColor: "#FFFFFF",
              borderRadius: 20,
              padding: 28,
              flexDirection: "row",
              alignItems: "center",
              gap: 20,
              borderWidth: 1.5,
              borderColor: "#E5E7EB",
            }}
          >
            <View
              style={{
                width: 56,
                height: 56,
                borderRadius: 14,
                backgroundColor: "#F3F4F6",
                justifyContent: "center",
                alignItems: "center",
              }}
            >
              <UtensilsCrossed size={28} color="#111827" />
            </View>
            <View style={{ flex: 1 }}>
              <Text
                style={{
                  fontSize: 20,
                  fontWeight: "700",
                  color: "#111827",
                  marginBottom: 4,
                }}
              >
                Restaurant owner
              </Text>
              <Text style={{ fontSize: 14, color: "#6B7280", lineHeight: 20 }}>
                Manage your menu, generate QR codes and view orders
              </Text>
            </View>
          </TouchableOpacity>
        </View>
      </View>
    </View>
  );
}
