"use client";
import { useState, useEffect, useMemo } from "react";
import {
  ShoppingCart,
  Plus,
  Minus,
  ArrowLeft,
  CheckCircle2,
  X,
  ClipboardList,
} from "lucide-react";
import { useQuery, useMutation } from "@tanstack/react-query";

export default function OrderPage({ params }) {
  const { qrId } = params;

  const [cart, setCart] = useState([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [customerName, setCustomerName] = useState("");
  const [notes, setNotes] = useState("");
  const [placedOrderId, setPlacedOrderId] = useState(null); // tracks orderId after submit
  const [showPopup, setShowPopup] = useState(false);

  // Fetch Menu Data
  const { data, isLoading, error } = useQuery({
    queryKey: ["menu", qrId],
    queryFn: async () => {
      const res = await fetch(`/api/menu/${qrId}`);
      if (!res.ok) throw new Error("Menu not found or QR code expired");
      return res.json();
    },
  });

  const submitOrder = useMutation({
    mutationFn: async (orderData) => {
      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderData),
      });
      if (!res.ok) throw new Error("Failed to submit order");
      return res.json();
    },
    onSuccess: (data) => {
      setPlacedOrderId(data.id);
      setShowPopup(true);
      setCart([]);
      setIsCartOpen(false);
    },
  });

  const restaurant = data?.restaurant;
  const menuItems = data?.menuItems || [];

  const categories = useMemo(() => {
    const cats = new Set(menuItems.map((item) => item.category || "Menu"));
    return Array.from(cats);
  }, [menuItems]);

  const addToCart = (item) => {
    setCart((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing)
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + 1 } : i,
        );
      return [...prev, { ...item, quantity: 1 }];
    });
  };

  const updateQuantity = (id, delta) => {
    setCart((prev) =>
      prev
        .map((item) => {
          if (item.id === id) {
            const newQ = item.quantity + delta;
            return newQ > 0 ? { ...item, quantity: newQ } : null;
          }
          return item;
        })
        .filter(Boolean),
    );
  };

  const cartTotal = cart.reduce(
    (sum, item) => sum + Number(item.price) * item.quantity,
    0,
  );

  const handleCheckout = () => {
    if (!customerName.trim()) {
      alert("Please enter your name");
      return;
    }

    submitOrder.mutate({
      qr_code_id: data.qrCode.id,
      restaurant_id: restaurant.id,
      customer_name: customerName,
      notes: notes,
      total: cartTotal,
      items: cart.map((item) => ({
        menu_item_id: item.id,
        item_name: item.name,
        item_price: item.price,
        quantity: item.quantity,
        subtotal: Number(item.price) * item.quantity,
      })),
    });
  };

  if (isLoading)
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center text-sm text-gray-500">
        Loading menu...
      </div>
    );
  if (error)
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center text-sm text-red-600">
        {error.message}
      </div>
    );

  return (
    <div className="min-h-screen bg-gray-50 pb-24 font-sans">
      {/* ===== ORDER PLACED POPUP ===== */}
      {showPopup && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-6">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-sm p-8 text-center relative">
            <button
              onClick={() => setShowPopup(false)}
              className="absolute top-4 right-4 text-gray-400 hover:text-gray-600"
            >
              <X size={18} />
            </button>
            <div className="flex items-center justify-center w-20 h-20 rounded-full bg-green-50 mx-auto mb-4">
              <CheckCircle2 className="w-10 h-10 text-green-500" />
            </div>
            <h2 className="text-xl font-bold text-gray-900 mb-2">
              Order Placed!
            </h2>
            <p className="text-sm text-gray-500 mb-6">
              Your order has been sent to{" "}
              <span className="font-medium text-gray-800">
                {restaurant?.name}
              </span>
              . We'll start preparing it shortly!
            </p>
            <a
              href={`/order-status/${placedOrderId}`}
              className="flex items-center justify-center gap-2 w-full bg-blue-600 text-white rounded-xl py-3 font-semibold text-sm hover:bg-blue-700 transition-colors mb-3"
            >
              <ClipboardList size={16} />
              View Order Status
            </a>
            <button
              onClick={() => setShowPopup(false)}
              className="w-full text-sm text-gray-400 hover:text-gray-600 py-2"
            >
              Back to menu
            </button>
          </div>
        </div>
      )}

      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-6 py-8">
        <h1 className="text-3xl font-semibold text-gray-900 tracking-tight">
          {restaurant?.name}
        </h1>
        <p className="text-sm text-gray-500 mt-2">
          Tap an item to add it to your order.
        </p>
      </header>

      {/* Menu Categories */}
      <div className="px-4 py-6 space-y-8">
        {categories.map((category) => (
          <div key={category}>
            <div className="mb-4">
              <span className="bg-white border border-gray-200 rounded-full px-3 py-1 text-xs font-medium text-gray-700 inline-flex items-center">
                {category}
              </span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {menuItems
                .filter((item) => (item.category || "Menu") === category)
                .map((item) => {
                  const inCart = cart.find((c) => c.id === item.id);
                  return (
                    <div
                      key={item.id}
                      className="bg-white rounded-xl border border-gray-200 p-4 flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex justify-between items-start gap-4">
                          <h3 className="text-base font-semibold text-gray-900">
                            {item.name}
                          </h3>
                          <span className="text-sm font-semibold text-gray-900 whitespace-nowrap">
                            ৳{Number(item.price).toFixed(0)}
                          </span>
                        </div>
                        {item.description && (
                          <p className="text-sm text-gray-500 mt-1">
                            {item.description}
                          </p>
                        )}
                      </div>

                      <div className="mt-4 flex items-center justify-end">
                        {inCart ? (
                          <div className="flex items-center gap-3 bg-gray-50 border border-gray-200 rounded-full px-1 py-1">
                            <button
                              onClick={() => updateQuantity(item.id, -1)}
                              className="w-8 h-8 flex items-center justify-center rounded-full bg-white border border-gray-200 text-gray-600"
                            >
                              <Minus size={14} />
                            </button>
                            <span className="text-sm font-semibold w-4 text-center">
                              {inCart.quantity}
                            </span>
                            <button
                              onClick={() => updateQuantity(item.id, 1)}
                              className="w-8 h-8 flex items-center justify-center rounded-full bg-white border border-gray-200 text-gray-600"
                            >
                              <Plus size={14} />
                            </button>
                          </div>
                        ) : (
                          <button
                            onClick={() => addToCart(item)}
                            className="bg-blue-50 text-blue-600 rounded-full px-4 py-1.5 text-sm font-medium inline-flex items-center gap-1.5 hover:bg-blue-100 transition-colors"
                          >
                            <Plus size={16} /> Add
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
            </div>
          </div>
        ))}
      </div>

      {/* Floating Cart Bar */}
      {cart.length > 0 && !isCartOpen && (
        <div className="fixed bottom-0 left-0 right-0 p-4 bg-white border-t border-gray-200">
          <div className="max-w-md mx-auto">
            <button
              onClick={() => setIsCartOpen(true)}
              className="w-full bg-blue-600 text-white rounded-xl py-3 px-4 flex items-center justify-between font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
            >
              <div className="flex items-center gap-2">
                <div className="bg-white/20 rounded-full w-6 h-6 flex items-center justify-center text-xs">
                  {cart.reduce((s, i) => s + i.quantity, 0)}
                </div>
                <span>View Order</span>
              </div>
              <span>৳{cartTotal.toFixed(0)}</span>
            </button>
          </div>
        </div>
      )}

      {/* Checkout Sheet */}
      {isCartOpen && (
        <div className="fixed inset-0 z-50 bg-white flex flex-col">
          <div className="border-b border-gray-200 px-4 py-4 flex items-center justify-between bg-white">
            <button
              onClick={() => setIsCartOpen(false)}
              className="text-gray-500 hover:text-gray-900 p-2"
            >
              <ArrowLeft size={20} />
            </button>
            <h2 className="text-lg font-semibold text-gray-900">Your Order</h2>
            <div className="w-10"></div>
          </div>

          <div className="flex-1 overflow-y-auto p-4 bg-gray-50 space-y-6">
            {/* Cart Items */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-4">
              {cart.map((item) => (
                <div
                  key={item.id}
                  className="flex justify-between items-start gap-4"
                >
                  <div>
                    <div className="text-sm font-semibold text-gray-900">
                      {item.name}
                    </div>
                    <div className="text-sm text-gray-500">
                      ৳{Number(item.price).toFixed(0)} x {item.quantity}
                    </div>
                  </div>
                  <div className="text-sm font-semibold text-gray-900">
                    ৳{(Number(item.price) * item.quantity).toFixed(0)}
                  </div>
                </div>
              ))}
              <div className="pt-4 border-t border-gray-200 flex justify-between items-center">
                <span className="text-base font-semibold text-gray-900">
                  Total
                </span>
                <span className="text-xl font-semibold text-gray-900">
                  ৳{cartTotal.toFixed(0)}
                </span>
              </div>
            </div>

            {/* Form */}
            <div className="bg-white rounded-xl border border-gray-200 p-4 space-y-4">
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">
                  Your Name
                </label>
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="e.g. John Doe"
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-500 mb-1">
                  Notes (Optional)
                </label>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  placeholder="Any allergies or special requests?"
                  className="w-full px-3 py-2 bg-white border border-gray-200 rounded-lg text-sm text-gray-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 min-h-[80px]"
                />
              </div>
            </div>
          </div>

          <div className="p-4 bg-white border-t border-gray-200">
            <button
              onClick={handleCheckout}
              disabled={submitOrder.isPending}
              className="w-full bg-blue-600 text-white rounded-xl py-3 px-4 flex items-center justify-center font-semibold focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 focus-visible:ring-offset-2 disabled:opacity-50"
            >
              {submitOrder.isPending
                ? "Sending..."
                : `Place Order • ৳${cartTotal.toFixed(0)}`}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
