"use client";
import { useEffect, useState } from "react";
import {
  CheckCircle2,
  Clock,
  ChefHat,
  BellRing,
  ArrowLeft,
} from "lucide-react";

const STATUS_STEPS = [
  {
    key: "pending",
    label: "Order Received",
    icon: Clock,
    color: "text-gray-500",
    bg: "bg-gray-100",
    ring: "ring-gray-300",
  },
  {
    key: "in_progress",
    label: "Preparing",
    icon: ChefHat,
    color: "text-amber-500",
    bg: "bg-amber-50",
    ring: "ring-amber-300",
  },
  {
    key: "ready",
    label: "Ready!",
    icon: BellRing,
    color: "text-green-500",
    bg: "bg-green-50",
    ring: "ring-green-300",
  },
  {
    key: "completed",
    label: "Completed",
    icon: CheckCircle2,
    color: "text-blue-500",
    bg: "bg-blue-50",
    ring: "ring-blue-300",
  },
];

export default function OrderStatusPage({ params }) {
  const { orderId } = params;
  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);

  const fetchOrder = async () => {
    try {
      const res = await fetch(`/api/orders/${orderId}`);
      if (!res.ok) throw new Error("Order not found");
      const data = await res.json();
      setOrder(data);
    } catch (e) {
      setError(e.message);
    }
  };

  useEffect(() => {
    fetchOrder();
    // Poll every 6 seconds for live status
    const interval = setInterval(fetchOrder, 6000);
    return () => clearInterval(interval);
  }, [orderId]);

  const currentIndex =
    STATUS_STEPS.findIndex((s) => s.key === order?.status) ?? 0;

  if (error)
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6 text-center">
        <div>
          <p className="text-red-500 text-sm mb-4">{error}</p>
          <a href="/" className="text-blue-600 text-sm underline">
            Go back
          </a>
        </div>
      </div>
    );

  if (!order)
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center text-sm text-gray-400">
        Loading your order...
      </div>
    );

  const currentStep = STATUS_STEPS[currentIndex] || STATUS_STEPS[0];
  const CurrentIcon = currentStep.icon;

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      {/* Header */}
      <header className="bg-white border-b border-gray-200 px-5 py-4 flex items-center gap-3">
        <a
          href={`/order/${order.qr_code_id}`}
          className="text-gray-400 hover:text-gray-700 transition-colors"
        >
          <ArrowLeft size={20} />
        </a>
        <h1 className="text-base font-semibold text-gray-900">Order Status</h1>
      </header>

      <div className="max-w-md mx-auto px-4 py-8 space-y-6">
        {/* Big status indicator */}
        <div
          className={`rounded-2xl p-8 text-center ${currentStep.bg} ring-1 ${currentStep.ring}`}
        >
          <div
            className={`inline-flex items-center justify-center w-20 h-20 rounded-full bg-white ring-2 ${currentStep.ring} mb-4`}
          >
            <CurrentIcon className={`w-10 h-10 ${currentStep.color}`} />
          </div>
          <p className={`text-2xl font-bold ${currentStep.color}`}>
            {currentStep.label}
          </p>
          <p className="text-sm text-gray-500 mt-2">
            {order.status === "pending" &&
              "We received your order and will start preparing it shortly."}
            {order.status === "in_progress" &&
              "Our kitchen is working on your order right now!"}
            {order.status === "ready" &&
              "Your order is ready! Please collect it from the counter."}
            {order.status === "completed" &&
              "Enjoy your meal! Thank you for ordering with us."}
          </p>
        </div>

        {/* Progress stepper */}
        <div className="bg-white rounded-xl border border-gray-200 p-5">
          <div className="flex items-center">
            {STATUS_STEPS.map((step, i) => {
              const isDone = i <= currentIndex;
              const StepIcon = step.icon;
              return (
                <div
                  key={step.key}
                  className="flex items-center flex-1 last:flex-none"
                >
                  <div className={`flex flex-col items-center`}>
                    <div
                      className={`w-8 h-8 rounded-full flex items-center justify-center transition-all
                      ${isDone ? "bg-blue-600" : "bg-gray-100"}`}
                    >
                      <StepIcon
                        className={`w-4 h-4 ${isDone ? "text-white" : "text-gray-400"}`}
                      />
                    </div>
                    <span
                      className={`text-[10px] font-medium mt-1 text-center leading-tight
                      ${isDone ? "text-blue-600" : "text-gray-400"}`}
                    >
                      {step.label}
                    </span>
                  </div>
                  {i < STATUS_STEPS.length - 1 && (
                    <div
                      className={`flex-1 h-0.5 mx-1 mb-4 transition-all ${i < currentIndex ? "bg-blue-600" : "bg-gray-200"}`}
                    />
                  )}
                </div>
              );
            })}
          </div>
        </div>

        {/* Order summary */}
        <div className="bg-white rounded-xl border border-gray-200 p-5 space-y-3">
          <div className="flex justify-between items-center mb-1">
            <h2 className="text-sm font-semibold text-gray-900">
              Order #{order.id}
            </h2>
            <span className="text-xs text-gray-400">
              {new Date(order.created_at).toLocaleTimeString([], {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </span>
          </div>
          <p className="text-xs text-gray-500 pb-2 border-b border-gray-100">
            Customer:{" "}
            <span className="text-gray-700 font-medium">
              {order.customer_name}
            </span>
          </p>
          <div className="space-y-2">
            {order.items?.map((item) => (
              <div key={item.id} className="flex justify-between text-sm">
                <span className="text-gray-700">
                  {item.quantity}x {item.item_name}
                </span>
                <span className="text-gray-900 font-medium">
                  ৳{Number(item.subtotal).toFixed(0)}
                </span>
              </div>
            ))}
          </div>
          <div className="pt-3 border-t border-gray-100 flex justify-between">
            <span className="font-semibold text-gray-900">Total</span>
            <span className="font-bold text-gray-900">
              ৳{Number(order.total).toFixed(0)}
            </span>
          </div>
        </div>

        <p className="text-center text-xs text-gray-400">
          This page refreshes automatically every 6 seconds
        </p>
      </div>
    </div>
  );
}
