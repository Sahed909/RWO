import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const id = params.id;
    const qrResult = await sql`SELECT * FROM qr_codes WHERE id = ${id}`;
    const qr = qrResult[0];
    if (!qr) return new Response("QR code not found", { status: 404 });

    const restaurantResult =
      await sql`SELECT * FROM restaurants WHERE id = ${qr.restaurant_id}`;
    const restaurant = restaurantResult[0];

    const appUrl = process.env.NEXT_PUBLIC_CREATE_APP_URL || "";
    const orderUrl = `${appUrl}/order/${id}`;
    const qrImageUrl = `https://api.qrserver.com/v1/create-qr-code/?size=400x400&margin=10&data=${encodeURIComponent(orderUrl)}`;

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>QR Code — ${restaurant?.name || ""}</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: Arial, sans-serif; display: flex; flex-direction: column; align-items: center; justify-content: center; min-height: 100vh; background: #fff; padding: 32px; }
    .card { border: 2px solid #111; border-radius: 16px; padding: 32px; text-align: center; max-width: 360px; width: 100%; }
    h1 { font-size: 22px; font-weight: 700; margin-bottom: 4px; }
    .subtitle { font-size: 13px; color: #666; margin-bottom: 24px; }
    img { width: 280px; height: 280px; display: block; margin: 0 auto 20px; }
    .label { font-size: 12px; color: #888; margin-top: 12px; }
    .name { font-size: 15px; font-weight: 600; color: #111; }
    @media print { body { padding: 0; } }
  </style>
</head>
<body>
  <div class="card">
    <h1>${restaurant?.name || "Our Menu"}</h1>
    <div class="subtitle">Scan to view menu & order</div>
    <img src="${qrImageUrl}" alt="QR Code"/>
    <div class="name">${qr.label}</div>
    <div class="label">${qr.type === "permanent" ? "Permanent QR" : "Temporary QR"}</div>
  </div>
  <script>window.onload = () => window.print();</script>
</body>
</html>`;

    return new Response(html, {
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  } catch (error) {
    console.error(error);
    return new Response("Failed to generate QR print page", { status: 500 });
  }
}
