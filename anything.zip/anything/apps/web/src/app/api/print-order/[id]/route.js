import sql from "@/app/api/utils/sql";

export async function GET(request, { params }) {
  try {
    const id = params.id;
    const orderResult = await sql`SELECT * FROM orders WHERE id = ${id}`;
    const order = orderResult[0];
    if (!order) return new Response("Order not found", { status: 404 });

    const items = await sql`SELECT * FROM order_items WHERE order_id = ${id}`;
    const restaurantResult =
      await sql`SELECT * FROM restaurants WHERE id = ${order.restaurant_id}`;
    const restaurant = restaurantResult[0];

    const itemRows = items
      .map(
        (item) => `
      <tr>
        <td style="padding:6px 0;border-bottom:1px solid #eee;">${item.item_name}</td>
        <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:center;">${item.quantity}</td>
        <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right;">৳${Number(item.item_price).toFixed(0)}</td>
        <td style="padding:6px 0;border-bottom:1px solid #eee;text-align:right;">৳${Number(item.subtotal).toFixed(0)}</td>
      </tr>
    `,
      )
      .join("");

    const time = new Date(order.created_at).toLocaleString("en-BD", {
      dateStyle: "medium",
      timeStyle: "short",
    });

    const html = `<!DOCTYPE html>
<html>
<head>
  <meta charset="UTF-8"/>
  <title>Order #${order.id} — ${restaurant?.name || ""}</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { font-family: Arial, sans-serif; font-size: 13px; color: #111; padding: 24px; max-width: 480px; margin: 0 auto; }
    h1 { font-size: 20px; font-weight: 700; margin-bottom: 2px; }
    .meta { color: #666; font-size: 12px; margin-bottom: 20px; }
    table { width: 100%; border-collapse: collapse; margin-bottom: 16px; }
    th { text-align: left; font-size: 11px; color: #888; padding-bottom: 6px; border-bottom: 2px solid #111; }
    th:nth-child(2) { text-align: center; }
    th:nth-child(3), th:nth-child(4) { text-align: right; }
    .total-row td { padding-top: 10px; font-weight: 700; font-size: 15px; }
    .notes { background: #fffbeb; border: 1px solid #fde68a; border-radius: 6px; padding: 10px; font-size: 12px; margin-bottom: 16px; }
    .footer { text-align: center; font-size: 11px; color: #999; margin-top: 24px; }
    @media print { body { padding: 0; } }
  </style>
</head>
<body>
  <h1>${restaurant?.name || "Restaurant"}</h1>
  <div class="meta">Order #${order.id} &nbsp;·&nbsp; ${time}</div>

  <div style="margin-bottom:16px;">
    <strong>Customer:</strong> ${order.customer_name}
  </div>

  ${order.notes ? `<div class="notes"><strong>Note:</strong> ${order.notes}</div>` : ""}

  <table>
    <thead>
      <tr>
        <th>Item</th>
        <th style="text-align:center;">Qty</th>
        <th style="text-align:right;">Price</th>
        <th style="text-align:right;">Subtotal</th>
      </tr>
    </thead>
    <tbody>
      ${itemRows}
      <tr class="total-row">
        <td colspan="3" style="padding-top:12px;border-top:2px solid #111;">Total</td>
        <td style="padding-top:12px;border-top:2px solid #111;text-align:right;">৳${Number(order.total).toFixed(0)}</td>
      </tr>
    </tbody>
  </table>

  <div class="footer">Powered by QRMenu</div>

  <script>window.onload = () => window.print();</script>
</body>
</html>`;

    return new Response(html, {
      headers: { "Content-Type": "text/html; charset=utf-8" },
    });
  } catch (error) {
    console.error(error);
    return new Response("Failed to generate print page", { status: 500 });
  }
}
