import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");

  try {
    if (id) {
      const restaurants = await sql`SELECT * FROM restaurants WHERE id = ${id}`;
      return Response.json(restaurants[0] || null);
    }
    const restaurants = await sql`SELECT * FROM restaurants`;
    return Response.json(restaurants);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to fetch restaurants" },
      { status: 500 },
    );
  }
}

export async function POST(request) {
  try {
    const { name } = await request.json();
    if (!name) {
      return Response.json({ error: "Name is required" }, { status: 400 });
    }

    const newRestaurant = await sql`
      INSERT INTO restaurants (name)
      VALUES (${name})
      RETURNING *
    `;

    return Response.json(newRestaurant[0]);
  } catch (error) {
    console.error(error);
    return Response.json(
      { error: "Failed to create restaurant" },
      { status: 500 },
    );
  }
}
